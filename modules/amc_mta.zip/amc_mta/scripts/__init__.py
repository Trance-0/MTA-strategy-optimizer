"""AMC MTA command scripts."""
